#' use ISC.MEB to cluster
#'
#' @usage Cluster and visualize data
#' @param The data entered is the processed RDA file and k is the number of clusters
#' @return  A visual cluster plot is returned and saved in the current folder, along with the ARI values of each plot and the overall ARI value
#' @name ISCcluster
#'
#' @export
library(devtools)
library(iSC.MEB)
library(Seurat)
ISCcluster=function(data,k){
  load(data)
  iSCMEBObj <- CreateiSCMEBObject(seuList = seuList, verbose = FALSE, premin.spots = 0, postmin.spots = 0)
  iSCMEBObj <- CreateNeighbors(iSCMEBObj, platform = "Visium")
  iSCMEBObj <- runPCA(iSCMEBObj, npcs = 15, pca.method = "APCA")
  iSCMEBObj <- SetModelParameters(iSCMEBObj, verbose = TRUE)
  iSCMEBObj <- iSCMEB(iSCMEBObj, K = k)
  iSCMEBObj <- SelectModel(iSCMEBObj)
  LabelList <- lapply(iSCMEBObj@seulist, function(seu) seu@meta.data$layer_guess_reordered)
  ARI <- function(x, y) mclust::adjustedRandIndex(x, y)
  ari_sections <- sapply(1:2, function(i) ARI(idents(iSCMEBObj)[[i]], LabelList[[i]]))
  ari_all <- ARI(unlist(idents(iSCMEBObj)), unlist(LabelList))
  ari_sections=data.frame(ari_sections)
  ari_all=data.frame(ari_all)
  cols = c("#fb8072", "#bebada", "#80b1d3", "#ffffb3", "#8dd3c7", "#b3de69", "#fdb462")
  p1 <- SpaHeatMap(iSCMEBObj, item = "cluster", plot_type = "Scatter", nrow.legend = 1, layout.dim = c(1,
                                                                                                       2), no_axis = TRUE, cols = cols)
  p1
  ggsave("p1.png",width = 6, height = 4, dpi = 300)
  print(ari_sections)
  print(ari_all)
}
